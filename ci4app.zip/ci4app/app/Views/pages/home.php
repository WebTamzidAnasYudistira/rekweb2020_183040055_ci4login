<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<div class="container mt-4">
  <div class="row">
    <div class="col">
      <h1>Hallo Nama Saya :<u>Tamzid Anas Yudistira</u> NRP : 183040055.</h1>
    </div>
  </div>
</div>
<?= $this->endSection() ?>